$('div').css({"text-shadow":"3px 3px #FF0244"});

$('div').css({"transform":"rotate(10deg)"});

$('img').attr({'src': 'https://imgix.bustle.com/mic/nw4xe84tdqyi15keub0uwxztffaoccnszvdoxhu2cqq8yljicsirx8dw3u4emz1y.jpg?w=1020&h=576&fit=crop&crop=faces&auto=format&q=70'});

$('img').attr({'src': 'https://i.pinimg.com/736x/2f/54/82/2f548286979402c5a69d6ae55e26ad5a.jpg'});

$('p').click(function() {

	$('p').css({"background-color": 'pink'});

})

$('div').css({"text-shadow":"4px 4px #FF0000"});

$('page-content').css({"transform":"rotate(30deg)"});

$('*').css({'border':'10px solid #FF2423'});

$("p").css({"font-family":' "Comic Sans MS", cursive, sans serif'});

$('div').click( function() { $(this).css({"background-color": "orange"}) });

document.body.style.color = "red";
